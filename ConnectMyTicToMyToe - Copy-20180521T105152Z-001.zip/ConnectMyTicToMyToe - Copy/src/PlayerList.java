import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * This class is to manage the Gym. It holds information about the gym and the members within in 
 * 
 * @author Dara OSullivan
 * 
 */

public class PlayerList
{
	private ArrayList<Player> players;

	/**
	 * Constructor for objects of class Gym
	 */
	public PlayerList()
	{
		players = new ArrayList<Player>();
	}

	public ArrayList<Player> getPlayers()
	{
		return players;
	}

	public void add (Player player)
	{
		players.add (player); 
	}

	public void remove (Player player) {
		players.remove(player);
	}

	public String listPlayers(){

		String listPlayers = "";
		int index = 0;
		for (Player player: players)
		{
			listPlayers = listPlayers + index + ": " + player.toString() + "\n";
			index++;
		}
		if (listPlayers.equals(""))
		{
			return "No members";
		}
		else
		{
			return listPlayers;
		}    
	}



	@SuppressWarnings("unchecked")
		public void save() throws Exception {
			XStream xstream = new XStream(new DomDriver());
			ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("playerLists.xml"));
			out.writeObject(players);
			out.close();
		}


		public void load() throws Exception {
			XStream xstream = new XStream(new DomDriver());
			ObjectInputStream is = xstream.createObjectInputStream(new FileReader("playerLists.xml"));
			players = (ArrayList<Player>) is.readObject();
			is.close();
		}



	}