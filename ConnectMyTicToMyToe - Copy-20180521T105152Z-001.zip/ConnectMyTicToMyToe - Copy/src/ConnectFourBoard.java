
public class ConnectFourBoard extends Board {
	Player player;

	    protected int BOTTOM_ROW = row -1;

		public ConnectFourBoard(int row, int col) {
			super(row, col);
			createBoard();
		}
	    
	   public boolean GameOver(int col, int row) {
 			 if (board[0][col] == board[1][col]
 					 && board[0][col] == board[2][col])
 					 return true;
 				 if (board[row][0] == board[row][1]
 						 && board[row][0] == board[row][2])
 					 return true;
 				 if (board[0][0]== board[1][1] && board[0][0] == board[2][2]
 						 && board[1][1] !='_')
 					 return true;
 				 if (board[0][2] == board[0][0] && board[0][2] == board[2][0]
 						 && board[1][1] !='_')
 				 if (board[0][3] == board[0][0] && board[0][3] == board[3][0]
 						 && board[1][1] !='_')
 					 return true;
 				 
 				 
 				 return false;
 				 
 			 }
}
