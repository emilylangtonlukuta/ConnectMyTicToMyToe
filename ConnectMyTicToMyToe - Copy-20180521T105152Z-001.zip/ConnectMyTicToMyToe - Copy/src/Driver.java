import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;


/**
 * The purpose of the Driver is to manage the menu and 
 * the save/load option for existing players
 * @author Aishling McPartland, Dara O'Sullivan, Emily Lukuta & Susan McCarthy
 * @version 1.0
 *
 */

public class Driver {
	private Scanner input;
	//board
	Board board;
	Player player;
	public int row, col;
	public char  turn = player.getPlayerToken();
	//startMenu();
	
	//main
	 public static void main(String[] args){
			
	 }
	
	void startMenu() {
		System.out.println("Do you want to play using existing players or set up new ones?");
		System.out.println("         1) Existing player");
		System.out.println("         2) New player");
		System.out.println("         Enter your option:");
		int option = input.nextInt();
		//return option;
		
		//cases for new player, quit, load & save
		switch (option) {
		case 1: loadExistingPlayer();
				break;
		case 2: addPlayer();
				break;
		}

		chooseGame();
		
		}
	
	
	public void Play() {
		boolean playing = true;
		beginConnectFour(col, row);
		beginTicTacToe(col, row);
		while(playing) {
			System.out.println("please select a row and column");
			row = input.nextInt() -1;
			col = input.nextInt() -1;
			//call a method in board...
			board.createBoard();

			if (ConnectFourBoard.GameOver(col, row)) {
				playing = false;
				System.out.println("Game over! Player" + turn +"wins!");
			}
			
			board.printBoard();
			if (turn == player.getPlayerToken())
				turn = player.getPlayerToken();
			else
				turn = player.getPlayerToken();
		}
		
	}
	
	
	public void chooseGame() {
		//give option to choose game
		System.out.println("Which game do you want to play?");
		System.out.println("         1) Connect Four");
		System.out.println("         2) Tic Tac Toe");
		System.out.println("Enter your option: ");
		int game = input.nextInt();
		if (game == 1) {
			System.out.println("What height board do you want: ");
			int height = input.nextInt();
			System.out.println("What width board do you want: ");
			int width = input.nextInt();
			beginConnectFour(height, width);
		}
		else {
			Play();
		}
	}
	
	public void loadExistingPlayer() {
		PlayerList.listPlayers();
		input.nextInt();
	}
	
	public void addPlayer(player) {
		//allows menu for name + token to appear
		System.out.println("Please enter player details:");
		input.nextLine();
		System.out.println("Enter player 1 name (max 30 chars): ");
		String player1Name = input.nextLine();
		System.out.println("          Enter their token (One char): ");
		char player1Token = input.next().charAt(0);
		Player.add(new player(getPlayerName, getPlayerToken()));
		
	
		return chooseGame();
			
	}
	
	
	
  	public void beginConnectFour(int col, int row) {
    //creates board
    board.createBoard();

    //tells player how to play
    System.out.println("Enter a number between 0-7 to choose which column you want:");

    //this method connects to the connect 4 class & displays the board
    board.printBoard();

    //creates boolean to determine status of game
    boolean flag = true;

    //main game loop
    while(flag){
        //begins player 1's turn, then prints board
        board.Drop(col, row, player);
        board.printBoard();

        //determines if player 1 has won
        if(!board.Check()){
            flag = false; //sets flag to false so loop is not repeated if player 1 won
            break; //break to skip player 2s turn if won
        }
    }
  }
  	
  	
  	public void beginTicTacToe(int col, int row) {
  		
  	   //creates board
  	    board.createBoard();

  	    //this method connects to the connect 4 class & displays the board
  	    board.PrintBoard();

  	    //creates boolean to determine status of game
  	    boolean flag = true;

  	    //main game loop
  	    while(flag){
  	        //begins player 1's turn, then prints board
  	        board.Drop(col, row, player);
  	        board.PrintBoard();

  	        //determines if player 1 has won
  	        if(!board.Check()){
  	            flag = false; //sets flag to false so loop is not repeated if player 1 won
  	            break; //break to skip player 2s turn if won
  	        }
  	    }
  		
  	}
  	
  	
  	
}
	
	

