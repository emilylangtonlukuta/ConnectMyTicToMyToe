
public class Player {
	
	private String playerName;
	private char playerToken;
	Player player;
	
	public Player(String player1Name, char player1Token) {
		if (player1Name.length() < 30) {
			this.playerName = player1Name;
		}
		else {
			//?sdr? substring to 30 characters instead of printing
			//System.out.print("Error");
		}
		
		//?sdR? set up the token field using the value passed as a paramter
	}

	/**
	 * @return the playerName
	 */
	public String getPlayerName() {
		return playerName;
	}

	/**
	 * @param playerName the playerName to set
	 */
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	/**
	 * @return the playerToken
	 */
	public char getPlayerToken() {
		return playerToken;
	}

	/**
	 * @param playerToken the playerToken to set
	 */
	public void setPlayerToken(char playerToken) {
		this.playerToken = playerToken;
	}
	
	//?sdr? generate accesors and mutators using eclipse.  right click, select source
	
	//?Sdr? generate toString...
	
}
