
public abstract class Board {
	
	protected char[][] board;
	protected int row;
    protected int col;
    Player player;
    protected int BOTTOM_ROW = row -1;

    
	public Board(int row, int col) {
	    board =  new char[row][col];
		this.row = row;
		this.col = col;	
	}
	
	public void createBoard() {
	
	//fills board with '_' for the width and height
    for (int w = 0; row > w; w += 1) {
        for (int h = 1; col > h; h += 1) {
            board[w][h] = '_';
	
	//?sdr? any common method name in the sub classes (diffferent implementation) -
	// these can be made abstract like createBoard....e.g. public String printBoard, 
	// public boolean placeCounter(coordinates????)
            
        }
        
        
            
        }
	}
        
	 public boolean Drop(int row, int col, Player player){
	        //creates a counter
	        int counter = 1;
 {
		//creates boolean to determine status of game
    boolean flag = true;

    //main game loop
    while(flag){
        //activates player 1s turn, then prints board
        Drop(row, col, player);
        printBoard();

        //determines if player 1 has won
        if(!Check()){
            flag = false; //sets flag to false so loop is not repeated if player 1 won
            break; //break to skip player 2s turn if won
        }
    }
	return flag;
	}

}
	 
	 public boolean CheckDiagonalBack(){
	        //flag
	        boolean flag = true;

	        //counter
	        int counter = 0;

	        //check boolean
	        boolean check = false;

	        //checkers
	        int checkColumn = 1;
	        int checkRow = 1;

	        while(flag){ //goes through until one of Player 1's tokens is found
	            for(int w = 0; row > w; w += 1){
	                for(int h = 0; col > h; h += 1){
	                    if(board[w][h] == player.getPlayerToken()){ //if one of Player 1's tokens is found, add one to counter and go into loop
	                        counter += 1;
	                        check = true;
	                        while(check){ //goes through diagonally looking for Player 1's tokens
	                            if(w - checkColumn >= 0 && h - checkRow >= 0){
	                                if(board[w - checkColumn][h - checkRow] == player.getPlayerToken()){
	                                    counter += 1; //if one of Player 1's tokens is found, add 1 to counter
	                                }
	                            }

	                            //adds 1 to checkers
	                            checkColumn += 1;
	                            checkRow += 1;

	                            if(checkColumn == 0 || checkRow == col -1){ //if outside of board, break
	                                check = false;
	                                break;
	                            }

	                            if(counter >= 4){
	                                System.out.println(player.getPlayerName() + " wins!"); //if counter is greater or equal to 4, player wins
	                                check = false;
	                                flag = false;
	                                break;
	                            }
	                        }
	                    }
	                    if(counter >= 4){
	                        flag = false;
	                        break;
	                    }

	                    //resets counter and checkers
	                    counter = 0;
	                    checkColumn = 1;
	                    checkRow = 1;
	                }
	            }
	            break;
	        }
	        return flag;
	    }


	    public boolean CheckDiagonalForward(){
	        //flag
	        boolean flag = true;

	        //counter
	        int counter = 0;

	        //check boolean
	        boolean check = false;

	        //checkers
	        int checkColumn = 1;
	        int checkRow = 1;

	        while(flag){ //goes through until one of Player 1's tokens is found
	            for(int w = 0; row > w; w += 1){
	                for(int h = 0; col > h; h += 1){
	                    if(board[w][h] == player.getPlayerToken()){ //if Player 1's token is found, add one to counter and go into loop
	                        counter += 1;
	                        check = true;
	                        while(check){ //goes through diagonally looking for Player 1's tokens
	                            if(checkColumn + w <= row - 1&& checkRow + h <= col - 1){
	                                if(board[w + checkColumn][h + checkRow] == player.getPlayerToken()){ //if one of Player 1's tokens is found, add 1 to counter
	                                    counter += 1;
	                                }
	                            }

	                            //adds 1 to checkers
	                            checkColumn += 1;
	                            checkRow += 1;

	                            if(checkColumn == row -1 || checkRow == col -1){ //if outside of board, break
	                                check = false;
	                                break;
	                            }

	                            if(counter >= 4){
	                                System.out.println(player.getPlayerName() + " wins!"); //if counter is greater or equal to 4, player wins
	                                check = false;
	                                flag = false;
	                                break;
	                            }
	                        }
	                    }
	                    if(counter >= 4){
	                        flag = false;
	                        break;
	                    }

	                    //resets counter and checkers
	                    counter = 0;
	                    checkColumn = 1;
	                    checkRow = 1;
	                }
	            }
	            break;
	        }
	        return flag;
	    }
	    
	    public boolean CheckVertical(){
	        //creates boolean to act as flag
	        boolean flag = true;

	        //creates counter
	        int counter = 0;
	        while(flag){

	            //goes through board vertically
	            for(int h = 0; col > h; h += 1){
	                for(int w = 0; row > w; w += 1){
	                    if(board[w][h] == player.getPlayerToken()){ //if it finds one of Player 1's tokens, add 1 to counter
	                        counter += 1;
	                    }else{
	                        counter = 0; // if next piece is not Player 1's tokens, set counter to 0
	                    }
	                    if(counter >= 4){
	                        System.out.println(player.getPlayerName() + " wins!"); //if counter is greater or equal to 4, player wins
	                        flag = false;
	                    }
	                }
	            }
	            break;
	        }
	        return flag;
	    }
	    
	    public boolean CheckHorizontal(){
	        //creates boolean to act as flag
	        boolean flag = true;

	        //creates counter
	        int counter = 0;
	        while(flag){

	            //goes through board horizontally
	            for(int w = 0; row > w; w += 1){
	                for(int h = 0; col > h; h += 1){
	                    if(board[w][h] == player.getPlayerToken()){ //if it finds one of Player 1's tokens, add 1 to counter
	                        counter += 1;
	                    }else{
	                        counter = 0; // if next piece is not Player 1's token, set counter to 0
	                    }
	                    if(counter >= 4){
	                        System.out.println(player.getPlayerName() + " wins!"); //if counter is greater or equal to 4, player wins
	                        flag = false;
	                    }
	                }
	            }
	            break;
	        }
	        return flag;
	    }
	 
	 public boolean Check(){
	        //creates flag
	        boolean flag = true;

	        //checks all of Player 1's tokens at once, for cleaner main loop
	        if(!CheckVertical() || !CheckHorizontal()|| !CheckDiagonalBack()|| !CheckDiagonalForward()){
	            flag = false;
	        }
	        return flag;
	    }
	 
	 public  String printBoard() {
		 String str = "";
		 for (int i=0;i<3;i++) {
			 str += "\n";
			 for (int j=0; j<3; j++) {
				 if (j == 0)
					 str += "|";
				     str += (board[i][j]+"|");
			 }
		 }
		 str += "\n";
		 return str;
	 }
	 
	 public void PrintBoard() {
	        //prints the board
	        for (int w = 0; row > w; w += 1) {
	            for (int h = 0; col > h; h += 1) {
	                System.out.print(board[w][h]+"|");
	            }
	            System.out.println();
	        }
	        System.out.println();
	    }
	
}